#LAB02   Charbel Fayad   ID:202102394
#Problem 5
#Write a program that reads an integer N and prints the 2 rightmost digits of N.
#Input: 328 => output: 28

number = input("Enter an integer: ")
print(number[-2:])

"""
 Observation: 
 we can use the slice operator to get the last two characters of a STRING.
 this help us to get the last two characters without worrying about the number 
 being negative or not.
 this is why we take input without converting it to an integer and use the slice operator.
 
 Input : -10328
 Output : 28
"""