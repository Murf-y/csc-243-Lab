#LAB02  Charbel Fayad   ID:202102394
#Problem 2
#In a program put the following expressions in print statements. Use two statements for each expression:
#5+3 		(Try once with double quotations and once without)
#5-3 		(Try once with double quotations and once without)
#5/2 		(Try once with double quotations and once without)
#5//2 	    (Try once with double quotations and once without)
#5*2 		(Try once with double quotations and once without)
#Save and Run your program.

print("5+3")
print(5+3)
print("5-3")
print(5-3)
print("5/2")
print(5/2)
print("5//2")
print(5//2)
print("5*2")
print(5*2)

"""
observation: 
 we can use the print function to print either a string literal or an expression.
Output:
    5+3
    8
    5-3
    2
    5/2
    2.5
    5//2
    2
    5*2
    10
"""
