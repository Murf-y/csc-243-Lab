#LAB02   Charbel Fayad   ID:202102394
#Problem 6:
#Write a program to find Hours, Minutes and seconds from seconds. 
#Include comments in your program. 
#Run it 5 times for 5 different input values and 
#complete the following table.

# get the seconds from the user and convert it to an integer
seconds = int(input("Enter the number of seconds: "))

# calculate the hours, minutes and seconds use integer division and modulo operator.
hours = seconds // 3600
minutes = (seconds % 3600) // 60
remaining_seconds = seconds % 60

# print the results using string formating
print("Hours: %d, Minutes: %d, Seconds: %d" % (hours, minutes, remaining_seconds))

"""
observation: 
    we can use the modulo operator to find the remainder of a division.
    we can use the %d in a print function to dynamically format the output.
    we can use the // operator to find the floor of a division.
Tabel showing the results of the program for mulitple input values
________________________________________________________
|   Input    | Output                                    |
|________________________________________________________|
|12345       | Hours: 3, Minutes: 25, Seconds: 45        |       
|54321       | Hours: 15, Minutes: 5, Seconds: 21        |
|2003        | Hours: 0, Minutes: 33, Seconds: 23        |
|3002        | Hours: 0, Minutes: 50, Seconds: 2         |
|11121314151 | Hours: 3089253, Minutes: 55, Seconds: 51  |
_________________________________________________________|

"""