#LAB02   Charbel Fayad   ID:202102394
#Problem 3
#Try these print functions below:
#print(“Hello”, “World!”)
#print(“Hello “,”World!”)
#print(“Hello “, “ World!”)
#print(“Hello”, “World!”, sep=”----“)
#s=”Hello World!”
#print(s)
#Comment at the end if you notice any difference concerning the first 3 functions, if you do not recognize any difference, type N/A.

print("Hello","World!")
print("Hello ","World!")
print("Hello "," World!")
print("Hello","World!",sep="----")
s="Hello World!"
print(s)

""" 
Output:             |             Observation:
 Hello World!       |  there is differene between the three frist print functions,
 Hello  World!      |  that difference is the space between the words,
 Hello   World!     |  in each function we added a space between the words.
 Hello----World!    | the sep parameter is used to separate the words with a specific string.
 Hello World!
"""