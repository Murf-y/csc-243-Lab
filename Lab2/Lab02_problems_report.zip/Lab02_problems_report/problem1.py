#LAB02   Charbel Fayad   ID:202102394
#Problem 1:
#Write a program that prints the text below to the screen. 
#Output:
#Hello World!
#Using Python is so easy
#I am the ‘King‘ of Python


print("Hello World!","Using Python is so easy","I am the ‘King‘ of Python",sep="\n")


""" 
observation:
we can use the 'sep' parameter to separate the arguments given to a print statement.
the default separator is a space.

Output:
    Hello World!
    Using Python is so easy
    I am the ‘King’ of Python
"""