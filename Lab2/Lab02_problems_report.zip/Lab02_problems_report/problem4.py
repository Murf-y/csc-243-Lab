#LAB02   Charbel Fayad   ID:202102394
#Problem 4
#The following program finds Minimum Number of Coins:
#Write it and run it 5 times for 5 different input values. Complete the Table below

# receive the amount
amount = eval(input("Enter an amount, for example, 11.56: "))

# convert the amount to cents
remainingAmount = int(amount * 100)

# find the number oof one dollars
numberOfOneDollars = remainingAmount // 100
remainingAmount = remainingAmount % 100

# Find the number of quarters in the remaining amount
numberOfQuarters = remainingAmount // 25
remainingAmount = remainingAmount % 25

# fine the number of dimes in the remaining amount
numberOfDimes = remainingAmount // 10
remainingAmount = remainingAmount % 10

# Find the number of nickels in the remaining amount
numberOfNickels = remainingAmount // 5
remainingAmount = remainingAmount % 5

#find the number of peices in the ramaining amount
numberOfPennies = remainingAmount

# display results
print("Your amount", amount, "consists of\n",
"\t",numberOfOneDollars, "dollars\n",
"\t",numberOfQuarters, "quarters\n",
"\t",numberOfDimes, "dimes\n",
"\t",numberOfNickels, "nickels\n",
"\t",numberOfPennies, "pennies\n")

"""
Observation:
we can use the modulo operator to find the remaining amount.

TABLE:
__________________________________
RUN 1:
Input: 11.56 
Output: Your amount 11.56 consists of
         11 dollars
         2 quarters
         0 dimes
         1 nickels
         1 pennies
__________________________________
RUN 2:
Input: 13.5
Output: Your amount 13.5 consists of
         13 dollars
         2 quarters
         0 dimes
         0 nickels
         0 pennies
___________________________________
RUN 3:
Input: 1.56
Output: Your amount 1.56 consists of
         1 dollars
         2 quarters
         0 dimes
         1 nickels
         1 pennies
___________________________________
RUN 4:
Input: 45.45
Output: Your amount 45.45 consists of
         45 dollars
         1 quarters
         2 dimes
         0 nickels
         0 pennies
___________________________________
RUN 5:
Input: 20.03
Output: Your amount 20.03 consists of
         20 dollars
         0 quarters
         0 dimes
         0 nickels
         3 pennies
___________________________________

"""